// API/controllers/authController.js - Handles authentication logic (register, login, resend verification, change password, profile update)

const bcrypt = require('bcryptjs'); // For hashing and comparing passwords
const jwt = require('jsonwebtoken'); // For creating and verifying JSON Web Tokens
const userModel = require('../models/userModel'); // Database interactions for users
const { secret, expiresIn, verificationSecret, verificationExpiresIn } = require('../config/jwt'); // JWT configuration
const { validateRegistration, validateLogin } = require('../utils/validation'); // Input validation
const emailService = require('../utils/emailService'); // Email sending service

/**
 * Registers a new user.
 * @param {Object} req - Express request object.
 * @param {Object} res - Express response object.
 * @param {Function} next - Express next middleware function.
 */
exports.register = async (req, res, next) => {
    try {
        const { username, email, password, name } = req.body; // Added 'name' from frontend

        // 1. Validate input data
        const { error } = validateRegistration(req.body);
        if (error) {
            const errors = error.details.map(detail => detail.message);
            return res.status(400).json({ message: 'Validation failed', errors: errors });
        }

        // 2. Check if user already exists (by email or username)
        const existingUser = await userModel.findByEmailOrUsername(email, username);
        if (existingUser) {
            if (existingUser.email === email) {
                return res.status(409).json({ message: 'Email already registered.' });
            }
            if (existingUser.username === username) {
                return res.status(409).json({ message: 'Username already taken.' });
            }
        }

        // 3. Hash the password
        const salt = await bcrypt.genSalt(10); // Generate a salt for hashing
        const hashedPassword = await bcrypt.hash(password, salt); // Hash the password

        // 4. Generate email verification token
        const verificationToken = jwt.sign({ email: email }, verificationSecret, { expiresIn: verificationExpiresIn });

        // 5. Create the user in the database
        // Pass 'name' and default 'Basic Plan' group, and null for profile picture initially
        const userId = await userModel.createUser(username, email, hashedPassword, verificationToken, 'Basic Plan', null, name);

        // 6. Send verification email
        const verificationLink = `${process.env.BACKEND_URL}/api/verify-email/${verificationToken}`;
        await emailService.sendVerificationEmail(email, username, verificationLink);

        // 7. Send success response
        res.status(201).json({
            message: 'User registered successfully! Please check your email to verify your account.',
            userId: userId,
        });

    } catch (error) {
        next(error);
    }
};

/**
 * Logs in an existing user.
 * @param {Object} req - Express request object.
 * @param {Object} res - Express response object.
 * @param {Function} next - Express next middleware function.
 */
exports.login = async (req, res, next) => {
    try {
        const { email, password } = req.body;

        // 1. Validate input data
        const { error } = validateLogin(req.body);
        if (error) {
            const errors = error.details.map(detail => detail.message);
            return res.status(400).json({ message: 'Validation failed', errors: errors });
        }

        // 2. Find user by email
        // Fetch all relevant user data including profile_picture_url and group_name
        const user = await userModel.findByEmail(email);
        if (!user) {
            return res.status(401).json({ message: 'Invalid credentials.' }); // Use generic message for security
        }

        // 3. Compare provided password with hashed password in DB
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(401).json({ message: 'Invalid credentials.' });
        }

        // 4. Check if email is verified
        if (!user.is_verified) {
            // If not verified, return 403 and include user ID and email
            return res.status(403).json({
                message: 'Please verify your email address to log in.',
                userId: user.id,
                email: user.email,
                username: user.username // Pass username to help identify user in modal
            });
        }

        // 5. Generate JWT token
        const tokenPayload = {
            id: user.id,
            email: user.email,
            is_verified: user.is_verified,
            username: user.username,
            name: user.name, // Include name
            group: user.group_name, // Use 'group_name' from DB
            profile_picture_url: user.profile_picture_url, // Include profile picture URL
            banned_until: user.banned_until,
            ban_reason: user.ban_reason
        };
        const token = jwt.sign(tokenPayload, secret, { expiresIn: expiresIn });

        // 6. Send success response
        res.status(200).json({
            message: 'Logged in successfully!',
            userId: user.id,
            token: token,
            // Send full user data for frontend context
            id: user.id,
            name: user.name,
            email: user.email,
            username: user.username,
            is_verified: user.is_verified,
            group: user.group_name,
            profile_picture_url: user.profile_picture_url,
            banned_until: user.banned_until,
            ban_reason: user.ban_reason,
            bio: user.bio,
            nationality: user.nationality,
            is_profile_public: user.is_profile_public
        });

    } catch (error) {
        next(error);
    }
};

/**
 * Resends a verification email to a user.
 * @param {Object} req - Express request object.
 * @param {Object} res - Express response object.
 * @param {Function} next - Express next middleware function.
 */
exports.resendVerificationEmail = async (req, res, next) => {
    try {
        const { email } = req.body;

        if (!email) {
            return res.status(400).json({ message: 'Email is required.' });
        }

        const user = await userModel.findByEmail(email);

        if (!user) {
            return res.status(404).json({ message: 'User with this email not found.' });
        }

        if (user.is_verified) {
            return res.status(400).json({ message: 'Email is already verified.' });
        }

        // Generate a new verification token
        const newVerificationToken = jwt.sign({ email: email }, verificationSecret, { expiresIn: verificationExpiresIn });

        // Update the user's verification token in the database
        const updateSuccess = await userModel.updateVerificationToken(user.id, newVerificationToken);

        if (!updateSuccess) {
            return res.status(500).json({ message: 'Failed to update verification token.' });
        }

        // Send the new verification email
        const verificationLink = `${process.env.BACKEND_URL}/api/verify-email/${newVerificationToken}`;
        await emailService.sendVerificationEmail(user.email, user.username, verificationLink);

        res.status(200).json({ message: 'Verification email resent successfully. Please check your inbox.' });

    } catch (error) {
        next(error);
    }
};

/**
 * Allows a logged-in user to change their password.
 * @param {Object} req - Express request object.
 * @param {Object} res - Express response object.
 * @param {Function} next - Express next middleware function.
 */
exports.changePassword = async (req, res, next) => {
    try {
        const { currentPassword, newPassword } = req.body;
        const userId = req.user.id; // Get user ID from the authenticated token

        if (!currentPassword || !newPassword) {
            return res.status(400).json({ message: 'Current password and new password are required.' });
        }

        if (newPassword.length < 6) {
            return res.status(400).json({ message: 'New password must be at least 6 characters long.' });
        }

        // 1. Fetch user from DB to compare current password
        const user = await userModel.findById(userId); // Need a findById method in userModel

        if (!user) {
            return res.status(404).json({ message: 'User not found.' }); // Should not happen if authMiddleware works
        }

        // 2. Compare provided current password with stored hashed password
        const isMatch = await bcrypt.compare(currentPassword, user.password);
        if (!isMatch) {
            return res.status(401).json({ message: 'Incorrect current password.' });
        }

        // 3. Hash the new password
        const salt = await bcrypt.genSalt(10);
        const hashedNewPassword = await bcrypt.hash(newPassword, salt);

        // 4. Update password in the database
        const updateSuccess = await userModel.updatePassword(userId, hashedNewPassword); // Need updatePassword method

        if (!updateSuccess) {
            return res.status(500).json({ message: 'Failed to update password.' });
        }

        res.status(200).json({ message: 'Password changed successfully.' });

    } catch (error) {
        next(error);
    }
};

/**
 * Allows a logged-in user to update their profile information (NEW).
 * @param {Object} req - Express request object.
 * @param {Object} res - Express response object.
 * @param {Function} next - Express next middleware function.
 */
exports.updateProfile = async (req, res, next) => {
    try {
        const userId = req.user.id; // User ID from authenticated token
        const updates = req.body; // Data to update (e.g., name, username, bio, nationality, is_profile_public, profile_picture_url)

        // Basic validation (you might want more robust validation here, e.g., using Joi)
        if (Object.keys(updates).length === 0) {
            return res.status(400).json({ message: 'No update data provided.' });
        }

        // Handle profile picture file upload if using multer or similar
        // For now, assuming profile_picture_url is sent directly or handled by a separate upload service
        // If you integrate Multer, this part would change to handle req.file

        const updateSuccess = await userModel.updateUserProfile(userId, updates);

        if (!updateSuccess) {
            return res.status(500).json({ message: 'Failed to update profile.' });
        }

        // Fetch the updated user data to send back to the frontend
        const updatedUser = await userModel.findById(userId);
        if (!updatedUser) {
            return res.status(500).json({ message: 'Failed to retrieve updated user data.' });
        }

        // Re-generate JWT with updated user data to ensure frontend has latest info
        const tokenPayload = {
            id: updatedUser.id,
            email: updatedUser.email,
            is_verified: updatedUser.is_verified,
            username: updatedUser.username,
            name: updatedUser.name,
            group: updatedUser.group_name,
            profile_picture_url: updatedUser.profile_picture_url,
            banned_until: updatedUser.banned_until,
            ban_reason: updatedUser.ban_reason
        };
        const newToken = jwt.sign(tokenPayload, secret, { expiresIn: expiresIn });


        res.status(200).json({
            message: 'Profile updated successfully!',
            user: { // Send back the updated user object for the frontend to consume
                id: updatedUser.id,
                name: updatedUser.name,
                email: updatedUser.email,
                username: updatedUser.username,
                is_verified: updatedUser.is_verified,
                group: updatedUser.group_name,
                profile_picture_url: updatedUser.profile_picture_url,
                banned_until: updatedUser.banned_until,
                ban_reason: updatedUser.ban_reason,
                bio: updatedUser.bio,
                nationality: updatedUser.nationality,
                is_profile_public: updatedUser.is_profile_public
            },
            token: newToken // Send new token with updated data
        });

    } catch (error) {
        next(error);
    }
};


// Example of a protected route
exports.getProtectedData = (req, res) => {
    // If this middleware is reached, the user is authenticated and email-verified via JWT
    res.status(200).json({
        message: 'This is protected data!',
        user: {
            id: req.user.id,
            email: req.user.email,
            is_verified: req.user.is_verified,
            username: req.user.username,
            name: req.user.name,
            group: req.user.group, // Use 'group' from req.user (from JWT payload)
            profile_picture_url: req.user.profile_picture_url, // Use profile_picture_url from JWT
            banned_until: req.user.banned_until,
            ban_reason: req.user.ban_reason
        }
    });
};
